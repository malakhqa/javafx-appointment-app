
package appointmentapp;
import java.sql.*;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Optional;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;

public class AppointmentApp extends Application {
     private String username;
     private String password;
     private String appointmentInfo;
     private String fullName;
     private static final String  UPDATE_USER="UPDATE STUDENTS SET NAME=?,EMAIL=?,PASSWORD=? WHERE ID=?" ;
     private static final String DELETE_USER="DELETE FROM STUDENTS WHERE EMAIL=?";
     
    // String url ="jdbc:mysql://localhost:3306/unistudents";
     TextField txtName,txtID,newUser, pswReg,userName1, Pass1,newPass, id2,name1,txtUser;
     Label iconLabel,lblHi;
     CheckBox darkMode;
     
     ListView<String> appointmentsList=new ListView<>();
     int currentStudent= -1;
       
    @Override
    public void start(Stage primaryStage) throws FileNotFoundException {
        //Scene1 Login 
        Label title = new Label("University Appointment System");
        title.setFont(Font.font("Arial", FontWeight.BOLD, 20));
//        title.setTextFill(Color.DARKBLUE);

        Label subtitle = new Label("Please log in to schedule your appointment");
        subtitle.setFont(Font.font("Arial", 14));
        subtitle.setTextFill(Color.GRAY);

        Label lblUser = new Label("Username (email):");
         txtUser = new TextField();
        txtUser.setPromptText("Username");

        Label lblPsw = new Label("Password:");
        PasswordField psw= new PasswordField();
        psw.setPromptText("Password");
        
        Button btnLogin = new Button("Login");
        Button btnRegister = new Button("Register");//move to register page
        Button btnExit=new Button("Exit");
        Button btnSignOut=new Button("Sign Out");
        
        hoverEffect(btnLogin);
        hoverEffect(btnRegister);
        hoverEffect(btnExit);
        hoverEffect(btnSignOut);

        GridPane login=new GridPane();
        login.setAlignment(Pos.CENTER);
        login.setHgap(10);
        login.setVgap(10);
        login.add(title, 1, 0);
        login.add(subtitle, 1, 1);
        login.add(lblUser, 0, 2);
        login.add(txtUser, 1, 2);
        login.add(lblPsw, 0, 3);
        login.add(psw, 1, 3);
        login.add(btnLogin, 0, 4);
        login.add(btnRegister, 1, 4);
        login.add(btnSignOut, 2, 4);
        login.add(btnExit, 3, 4);
        Scene scene1 = new Scene(login, 600, 400);
 
        //Scene2 Register
        Label registerTitle = new Label("Create a New Account");
        registerTitle.setFont(Font.font("Arial", FontWeight.BOLD, 20));
//        registerTitle.setTextFill(Color.DARKGREEN);

        Label registerSubtitle = new Label("Fill in your details to register");
        registerSubtitle.setFont(Font.font("Arial", 14));
        registerSubtitle.setTextFill(Color.GRAY);
        
        Label lblName=new Label("Name");
        txtName=new TextField();
        txtName.setPromptText("Name");
        
        Label lblID=new Label("ID");
        txtID=new TextField();
        txtID.setPromptText("ID");
        
        Label lblUsernew=new Label("Username (email)");
       newUser = new TextField();
       newUser.setPromptText("Username");
       
       Label lblPswReg=new Label("Password");
       pswReg=new TextField();
       pswReg.setPromptText("Password");
        
        Button btnRegister2=new Button("Register");
        Button btnBack=new Button("Back");
        
        hoverEffect(btnRegister2);
        hoverEffect(btnBack);
        
        GridPane register=new GridPane();
        register.setAlignment(Pos.CENTER);
        register.setHgap(10);
        register.setVgap(10);
        register.add(registerTitle, 1, 0);
        register.add(registerSubtitle, 1, 1);
        register.add(lblName, 0, 2);
        register.add(txtName, 1, 2);
        register.add(lblID, 0, 3);
        register.add(txtID, 1, 3);
        register.add(lblUsernew, 0, 4);
        register.add(newUser, 1, 4);
        register.add(lblPswReg, 0, 5);
        register.add(pswReg, 1, 5);
        register.add(btnRegister2, 0, 6);
        register.add(btnBack, 1, 6);
        Scene scene2 = new Scene(register, 600, 400);
        
        //Scene3 Homepage
        BorderPane homeRoot=new BorderPane();
        //Left Bar
        lblHi=new Label("Hello "+fullName);
        lblHi.setFont(Font.font("Arial", FontWeight.BOLD, 16));
//        lblHi.setTextFill(Color.DARKBLUE);
        
//        FileInputStream input=new FileInputStream("Images:\\profile_pic.jpg");
        Image profileImg=new Image("file:C:\\Users\\USER\\OneDrive - asu.edu.jo\\Documents\\NetBeansProjects\\appointmentApp\\src\\images\\profile_pic.jpg");
        ImageView profilePic = new ImageView(profileImg);
        double size=100;
        profilePic.setFitWidth(size);
        profilePic.setFitHeight(size);
        profilePic.setPreserveRatio(true);
        
        Circle clip = new Circle(size / 2, size / 2, size / 2);// X,Y,Radius
        profilePic.setClip(clip);
        
        Button btnSettings= new Button("Settings");
        btnSettings.setPrefSize(100, 20);  
        Button btnBack2=new Button("Back");
        btnBack2.setPrefSize(100, 20);
        Button btnExit2=new Button("Exit");
        btnExit2.setPrefSize(100, 20);
        ColorPicker colorPicker=new ColorPicker();
        
        hoverEffect(btnSettings);
        hoverEffect(btnBack2);
        hoverEffect(btnExit2);
        
        VBox leftBar=new VBox(lblHi,profilePic,btnSettings,btnBack2,btnExit2,colorPicker );
        leftBar.setPadding(new Insets(5,5,5,5));
        leftBar.setSpacing(10);
        leftBar.setAlignment(Pos.CENTER);
//        leftBar.setStyle("-fx-background-color: pink");
        colorPicker.setValue(Color.PINK);
        homeRoot.setLeft(leftBar);
        
        //Center content 
        appointmentsList=new ListView<>();
        Label lblAppointments=new Label("📅 Your Scheduled Appointments:");
        lblAppointments.setStyle("-fx-font-weight:bold;");
        Label welcomeText = new Label("Welcome to the Appointment Scheduler!");
        welcomeText.setFont(Font.font("Arial", FontWeight.BOLD, 18));
       
//        FileInputStream inputRadwan=new FileInputStream("Images:\\dr.Radwan.jpg");
        Image radwanImg = new Image("file:C:\\Users\\USER\\OneDrive - asu.edu.jo\\Documents\\NetBeansProjects\\appointmentApp\\src\\images\\dr.Radwan.jpg");
        ImageView radwanView = new ImageView(radwanImg);
        radwanView.setFitHeight(120);
        radwanView.setFitWidth(120);
        
        Button btnRadwan = new Button("",radwanView);
        btnRadwan.setTooltip(new Tooltip("Dr. Radwan Batyha"));
        btnRadwan.setContentDisplay(ContentDisplay.TOP);
        Label lblRadwan=new Label("Dr. Radwan Batyha");
        hoverEffect(btnRadwan);
//        FileInputStream inputBaraa=new FileInputStream("Images:\\dr.Baraa.jpg");
        Image baraaImg = new Image("file:C:\\Users\\USER\\OneDrive - asu.edu.jo\\Documents\\NetBeansProjects\\appointmentApp\\src\\images\\dr.Baraa.jpg");
        ImageView baraaView = new ImageView(baraaImg);
        
        baraaView.setFitHeight(120);
        baraaView.setFitWidth(120);
        Button btnBaraa = new Button("", baraaView);
        btnBaraa.setTooltip(new Tooltip("Dr Baraa Qadomi"));
        btnBaraa.setContentDisplay(ContentDisplay.TOP);
        Label lblBaraa=new Label("Dr Baraa Qadomi");
        hoverEffect(btnBaraa);
        
        GridPane gpCenter=new GridPane();
        gpCenter.setAlignment(Pos.CENTER);
        gpCenter.setPadding(new Insets(20));
        gpCenter.setVgap(20);
        gpCenter.setHgap(30);
        
        gpCenter.add(welcomeText,0,0,2,1);
        GridPane.setHalignment(welcomeText, HPos.CENTER);
        
        gpCenter.add(btnRadwan,0,1);
        gpCenter.add(btnBaraa,1,1);
        
        gpCenter.add(lblRadwan,0,2);
        GridPane.setHalignment(lblRadwan, HPos.CENTER);
        
        gpCenter.add(lblBaraa,1,2);
        GridPane.setHalignment(lblBaraa, HPos.CENTER);
        
        gpCenter.add(lblAppointments,0,3,2,1);
        gpCenter.add(appointmentsList,0,4,2,1);
        homeRoot.setCenter(gpCenter);
        appointmentsList.setPrefHeight(150);
        appointmentsList.setPlaceholder(new Label("No appointments found."));
        Scene scene3 = new Scene(homeRoot, 600, 400);
        
        //Scene4 Dr Radwan
//        FileInputStream inputRadwan2=new FileInputStream("Images:\\dr.Radwan.jpg");
        Image radwanImg2=new Image("file:C:\\Users\\USER\\OneDrive - asu.edu.jo\\Documents\\NetBeansProjects\\appointmentApp\\src\\images\\dr.Radwan.jpg");
        ImageView imageViewRadwan = new ImageView(radwanImg2);
        imageViewRadwan.setFitWidth(100);
        imageViewRadwan.setFitHeight(100);
        imageViewRadwan.setClip(new Circle(50, 50, 50)); // make it round

        Label nameRadwan = new Label("Dr. Radwan Batyha");
        nameRadwan.setFont(Font.font("Arial", FontWeight.BOLD, 18));

        Label major = new Label("Computer Science");
        major.setTextFill(Color.GRAY);

        Label fac = new Label("Information Technology");
        fac.setTextFill(Color.GRAY);

        Label contactLabel = new Label("CONTACT");
        contactLabel.setTextFill(Color.GRAY);
        contactLabel.setFont(Font.font("Arial", FontWeight.BOLD, 12));
        Label email = new Label("r_batiha@asu.edu.jo");
        email.setGraphic(new ImageView(new Image("https://img.icons8.com/ios-glyphs/20/000000/new-post.png")));
        
        Label duration = new Label("Note: Appointments must not exceed 30 minutes.");
        duration.setGraphic(new ImageView(new Image("https://img.icons8.com/ios-glyphs/20/000000/clock--v1.png")));
        Button btnSchaedule =new Button("Schedule Appointment");
        btnSchaedule.setPrefSize(200, 200);
        Button btnHomePage=new Button("Home Page");
        
        hoverEffect(btnSchaedule);
        hoverEffect(btnHomePage);
        
        //Office hours
        GridPane officeHours = new GridPane();
        officeHours.setHgap(10);
        officeHours.setVgap(5);
        officeHours.setAlignment(Pos.CENTER);

        officeHours.add(new Label("Day"), 0, 0);
        officeHours.add(new Label("Time"), 1, 0);

        officeHours.add(new Label("Sunday"), 0, 1);
        officeHours.add(new Label("10:00 - 12:00"), 1, 1);

        officeHours.add(new Label("Monday"), 0, 2);
        officeHours.add(new Label("1:00 - 3:00"), 1, 2);

        officeHours.add(new Label("Tuesday"), 0, 3);
        officeHours.add(new Label("11:00 - 1:00"), 1, 3);

        officeHours.add(new Label("Wednesday"), 0, 4);
        officeHours.add(new Label("9:00 - 11:00"), 1, 4);

        officeHours.add(new Label("Thursday"), 0, 5);
        officeHours.add(new Label("11:00 - 12:00"), 1, 5);

        VBox radwan = new VBox(10, imageViewRadwan, nameRadwan, major, fac, contactLabel, email,officeHours,duration,btnSchaedule,btnHomePage);
        radwan.setStyle("-fx-background-color: #f8f8f8; -fx-padding: 20; -fx-alignment: center; -fx-border-radius: 10; -fx-background-radius: 10;");
        
        //Appointment layout
        Label formTitle = new Label("Schedule an Appointment");
        formTitle.setFont(Font.font("Arial", FontWeight.BOLD, 14));
//      formTitle.setTextFill(Color.DARKBLUE);
        TextField studentName = new TextField();
        studentName.setPromptText("Your Name");
        TextField studentId = new TextField();
        studentId.setPromptText("Your ID");
        
        ComboBox<String> dayCombo = new ComboBox<>();
        dayCombo.getItems().addAll("Sunday", "Monday", "Tuesday", "Wednesday", "Thursday");
        dayCombo.setPromptText("Choose Day");
        
        TextField timeField = new TextField();
        timeField.setPromptText("Enter Time (e.g. 10:30)");
        Button btnSubmit =new Button("Submit Appointment");
        //Go to the result scene
        Button btnBacktoRadwan=new Button("Back");
        
        hoverEffect(btnSubmit);
        hoverEffect(btnBacktoRadwan);
        
        VBox form = new VBox(5, formTitle, studentName, studentId, dayCombo, timeField,btnSubmit,btnBacktoRadwan);
        form.setStyle("-fx-border-color: #cccccc; -fx-padding: 10; -fx-background-color: #ffffff;");
        form.setMaxWidth(300);
        form.setAlignment(Pos.CENTER);
        
       StackPane radwanViewContent=new StackPane(radwan,form);
        
        BorderPane mainLayout = new BorderPane(radwanViewContent);
        Scene scene4 = new Scene(mainLayout, 600, 600);
        
        //Scene5 Radwan Appointment
        Label resultTitle = new Label("Appointment Confirmation");
        resultTitle.setFont(Font.font("Arial", FontWeight.BOLD, 18));
        //Will be updated in the submitBtn
        Label drNameLabel = new Label(); 
        Label studentNameLabel = new Label();
        Label studentIdLabel = new Label();
        Label selectedDayLabel = new Label();
        Label selectedTimeLabel = new Label();
        Button btnFinish=new Button("Finish");
        
        hoverEffect(btnFinish);

        VBox radwanResult=new VBox(drNameLabel, studentNameLabel,studentIdLabel,selectedDayLabel,selectedTimeLabel,btnFinish);
        radwanResult.setAlignment(Pos.CENTER);
        radwanResult.setStyle("-fx-padding: 20;");
        Scene scene5 = new Scene(radwanResult, 600, 600);

        
        //Scene6 Dr Baraa
//        FileInputStream inputBaraa2=new FileInputStream("Images:\\dr.Baraa.jpg");
        Image baraaImg2 = new Image("file:C:\\Users\\USER\\OneDrive - asu.edu.jo\\Documents\\NetBeansProjects\\appointmentApp\\src\\images\\dr.Baraa.jpg");
        ImageView imageViewBaraa = new ImageView(baraaImg2);
        imageViewBaraa.setFitWidth(100);
        imageViewBaraa.setFitHeight(100);
        imageViewBaraa.setClip(new Circle(50, 50, 50)); // make it round

        Label nameBaraa = new Label("Dr. Baraa Qadomi");
        nameBaraa.setFont(Font.font("Arial", FontWeight.BOLD, 18));

        Label major2 = new Label("Computer Science");
        major2.setTextFill(Color.GRAY);

        Label fac2 = new Label("Information Technology");
        fac2.setTextFill(Color.GRAY);

        Label contactLabel2 = new Label("CONTACT");
        contactLabel2.setTextFill(Color.GRAY);
        contactLabel2.setFont(Font.font("Arial", FontWeight.BOLD, 12));
        Label email2 = new Label("b_qadomi@asu.edu.jo");
        email2.setGraphic(new ImageView(new Image("https://img.icons8.com/ios-glyphs/20/000000/new-post.png")));
        
        Label duration2 = new Label("Note: Appointments must not exceed 30 minutes.");
        duration2.setGraphic(new ImageView(new Image("https://img.icons8.com/ios-glyphs/20/000000/clock--v1.png")));
        Button btnSchaedule2 =new Button("Schedule Appointment");
        btnSchaedule2.setPrefSize(200, 200);
        Button btnHomePage2=new Button("Home Page");
        
        hoverEffect(btnSchaedule2);
        hoverEffect(btnHomePage2);
        
        //Office hours
        GridPane officeHours2= new GridPane();
        officeHours2.setHgap(10);
        officeHours2.setVgap(5);
        officeHours2.setAlignment(Pos.CENTER);

        officeHours2.add(new Label("Day"), 0, 0);
        officeHours2.add(new Label("Time"), 1, 0);

        officeHours2.add(new Label("Sunday"), 0, 1);
        officeHours2.add(new Label("9:00 - 11:00"), 1, 1);

        officeHours2.add(new Label("Monday"), 0, 2);
        officeHours2.add(new Label("2:00 - 3:00"), 1, 2);

        officeHours2.add(new Label("Tuesday"), 0, 3);
        officeHours2.add(new Label("10:00 - 12:00"), 1, 3);

        officeHours2.add(new Label("Wednesday"), 0, 4);
        officeHours2.add(new Label("1:00 - 3:00"), 1, 4);

        officeHours2.add(new Label("Thursday"), 0, 5);
        officeHours2.add(new Label("9:00 - 10:00"), 1, 5);
        
        VBox baraa = new VBox(10, imageViewBaraa, nameBaraa, major2, fac2, contactLabel2, email2,officeHours2,duration2,btnSchaedule2,btnHomePage2);
        baraa.setStyle("-fx-background-color: #f8f8f8; -fx-padding: 20; -fx-alignment: center; -fx-border-radius: 10; -fx-background-radius: 10;");
        
        //Appointment layout
        Label formTitle2 = new Label("Schedule an Appointment");
        formTitle2.setFont(Font.font("Arial", FontWeight.BOLD, 14));
//      formTitle2.setTextFill(Color.DARKBLUE);
        TextField studentName2 = new TextField();
        studentName2.setPromptText("Your Name");
        TextField studentId2 = new TextField();
        studentId2.setPromptText("Your ID");
        
        ComboBox<String> dayCombo2 = new ComboBox<>();
        dayCombo2.getItems().addAll("Sunday", "Monday", "Tuesday", "Wednesday", "Thursday");
        dayCombo2.setPromptText("Choose Day");
        
        TextField timeField2 = new TextField();
        timeField2.setPromptText("Enter Time (e.g. 10:30)");
        Button btnSubmit2 =new Button("Submit Appointment");
        //Go to the result scene
        Button btnBacktoBaraa=new Button("Back");
        
        hoverEffect(btnSubmit2);
        hoverEffect(btnBacktoBaraa);
        
        VBox form2 = new VBox(5, formTitle2, studentName2, studentId2, dayCombo2, timeField2,btnSubmit2,btnBacktoBaraa);
        form2.setStyle("-fx-border-color: #cccccc; -fx-padding: 10; -fx-background-color: #ffffff;");
        form2.setMaxWidth(300);
        form2.setAlignment(Pos.CENTER);
        
        StackPane baraaViewContent=new StackPane(baraa,form2);
        baraaViewContent.setAlignment(Pos.CENTER);
   
        BorderPane mainLayout2=new BorderPane(baraaViewContent);
        mainLayout2.setCenter(baraaViewContent);
        Scene scene6 = new Scene(mainLayout2, 600, 600);
        
        //Scene7 Baraa Appointment
        Label resultTitle2 = new Label("Appointment Confirmation");
        resultTitle2.setFont(Font.font("Arial", FontWeight.BOLD, 18));
        //Will be updated in the submitBtn
        Label drNameLabel2 = new Label(); 
        Label studentNameLabel2 = new Label();
        Label studentIdLabel2 = new Label();
        Label selectedDayLabel2 = new Label();
        Label selectedTimeLabel2 = new Label();
        Button btnFinish2=new Button("Finish");
        
        hoverEffect(btnFinish2);

        VBox baraaResult=new VBox(drNameLabel2, studentNameLabel2,studentIdLabel2,selectedDayLabel2,selectedTimeLabel2,btnFinish2);
        baraaResult.setAlignment(Pos.CENTER);
        baraaResult.setStyle("-fx-padding: 20;");
        Scene scene7 = new Scene(baraaResult, 600, 600);
        
        //Scene 8 settings
        //main layout
        BorderPane settings = new BorderPane();
        
        //Left content 
        Label lblSettings = new Label("Settings");
        lblSettings.setFont(Font.font("Arial", FontWeight.BOLD, 20));
        Label lblUserName = new Label();

        Button btnHome = new Button("Home");
        hoverEffect(btnHome);

//        // Theme Toggle
//        darkMode = new CheckBox("Dark Mode");
//        iconLabel = new Label("🌞");
//        darkMode.setGraphic(iconLabel);

        Label gender = new Label("Gender:");
        ToggleGroup genderGroup = new ToggleGroup();
        RadioButton male = new RadioButton("Male");
        RadioButton female = new RadioButton("Female");
        male.setToggleGroup(genderGroup);
        female.setToggleGroup(genderGroup);

        Label lblCity = new Label("Choose Your City:");
        ComboBox<String> combo = new ComboBox<>();
        combo.setPromptText("Amman");
        combo.getItems().addAll("Amman", "Irbid", "Zarqa", "Aqaba", "Karak");

        Label lblSummary = new Label();
        Button btnSaveChanges = new Button("Save Changes");
        hoverEffect(btnSaveChanges);
        
        //Right content 
        Label nameS = new Label("New Name:");
         name1 = new TextField();
        
        Label ID2 = new Label("Your ID:");
        id2 = new TextField();
        
        Label userName = new Label("User Name(email):");
        userName1 = new TextField();
        
        Label Pass = new Label("Password:");
        Pass1 = new TextField();
        
        Button btnChange = new Button("Update");
        hoverEffect(btnChange);
        
        VBox rightvbox = new VBox(10, nameS, name1, ID2, id2, userName, userName1,Pass, Pass1, btnChange);
        rightvbox.setAlignment(Pos.CENTER);
        rightvbox.setPadding(new Insets(50));
        rightvbox.setPrefWidth(400);

        VBox leftvbox = new VBox(10, lblSettings, lblUserName, gender, male, female, lblCity, combo, btnSaveChanges, btnHome, lblSummary);
        leftvbox.setAlignment(Pos.CENTER);
        leftvbox.setPadding(new Insets(20));
        leftvbox.setPrefWidth(200);

        HBox hbox = new HBox(leftvbox, rightvbox);
        hbox.setPrefWidth(600);
        HBox.setHgrow(rightvbox, Priority.ALWAYS);

        settings.setCenter(hbox);
        Scene scene8 = new Scene(settings, 600, 400);

        //Actions
        btnLogin.setOnAction(e -> {
            if(txtUser.getText().isEmpty()||psw.getText().isEmpty()){
            Alert alert=new Alert(Alert.AlertType.ERROR, "Please fill the empty text!");
            alert.show();
            alert.setTitle("Empty");
            }else{
            try{
                Connection conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/unistudents","root","");
                Statement st=conn.createStatement();
                ResultSet result=st.executeQuery("select * from students");
                boolean found=false;
                
                while(result.next()){
                username=result.getString("email");
                password=result.getString("password");
                if(username.equals(txtUser.getText()) && password.equals(psw.getText())){
                    fullName=result.getString("name");
                    currentStudent= result.getInt("id"); // Save student ID
                    lblHi.setText("Hi "+fullName);
                    found=true;
                    
                  // === Load appointments for this student ID ===
                  appointmentsList.getItems().clear();
                  
                  try{
                      Connection conn2=DriverManager.getConnection("jdbc:mysql://localhost:3306/unistudents","root","");
                       PreparedStatement stmt2 = conn2.prepareStatement(
                "SELECT drname, day, time FROM appointment WHERE id = ?");
                  stmt2.setInt(1, currentStudent);
                  ResultSet result2 = stmt2.executeQuery();
                       
                  while(result2.next()){
                   String item = "Dr. " + result2.getString("drname") +
                   " | Day: " + result2.getString("day") +
                   " | Time: " + result2.getString("time");
                appointmentsList.getItems().add(item);
                  }
                  conn2.close();
                  }
                  catch(Exception ex ){
                      ex.printStackTrace();
                  }
                    primaryStage.setScene(scene3); 
                    txtUser.clear();
                    psw.clear();
                    break;
                }
                }

                if(!found){
                Alert alert=new Alert(Alert.AlertType.ERROR,"User not found! You should to regirst first");
                alert.show();
                alert.setTitle("Not found");
                txtUser.clear();
                psw.clear();
                }

                conn.close();
       
            }
            catch(Exception ex){
               ex.printStackTrace();   
            }
            }
            
            
        });
        
        
        btnRegister.setOnAction(e-> primaryStage.setScene(scene2));
        
        btnExit.setOnAction(e->{
        Alert alert=new Alert(AlertType.CONFIRMATION);
        alert.setTitle("Exit");
        alert.setHeaderText("Exit");
        alert.setContentText("Are you sure you want to exit?");
        Optional<ButtonType> result= alert.showAndWait();
        if(result.get()==ButtonType.OK)
            System.exit(0);
        });
        btnExit2.setOnAction(e->{       
        Alert alert=new Alert(AlertType.CONFIRMATION);
        alert.setTitle("Exit");
        alert.setHeaderText("Exit");
        alert.setContentText("Are you sure you want to exit?");
        Optional<ButtonType> result= alert.showAndWait();
        if(result.get()==ButtonType.OK)
            System.exit(0);});
        
        //Using Methods
        btnRegister2.setOnAction(e->addStudent());
        btnSignOut.setOnAction(e->signOut());
        
        btnBack2.setOnAction(e->primaryStage.setScene(scene1) );
        
        colorPicker.setOnAction(e->{
       String colorHex = colorPicker.getValue().toString().replace("0x", "#").substring(0, 7);
       leftBar.setStyle("-fx-background-color: " + colorHex + ";");
        });
        
        
        btnRadwan.setOnAction(e ->{
        radwan.setVisible(true);      // Show Radwan's profile info again
         form.setVisible(false);       // Hide the form if it was left visible
          primaryStage.setScene(scene4);});
        
        btnBaraa.setOnAction(e -> {
        baraa.setVisible(true);
        form2.setVisible(false);
        primaryStage.setScene(scene6);
        });
        
        btnBack.setOnAction(e-> primaryStage.setScene(scene1));
        
        btnSchaedule.setOnAction(e->{
         radwan.setVisible(false);
         form.setVisible(true);
        });
        
        btnSchaedule2.setOnAction(e-> {
        baraa.setVisible(false);
        form2.setVisible(true);
        });
        
        //Radwan submtion and finishing
        btnSubmit.setOnAction(e->{
        String name = studentName.getText();
        String id = studentId.getText();
        String day = dayCombo.getValue();
        String time = timeField.getText(); 
        
        if(name.isEmpty()||id.isEmpty()|| day==null|| time.isEmpty()){
         Alert alert = new Alert(Alert.AlertType.WARNING);
        alert.setTitle("Missing Information");
        alert.setHeaderText(null);
        alert.setContentText("Please fill in all the fields before submitting.");
        alert.showAndWait();
        } else{
            try{
                Connection conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/unistudents","root","");
                PreparedStatement stmt = conn.prepareStatement(
                "INSERT INTO appointment (studentname, id, day, time,drname) VALUES (?, ?, ?, ?,?)"
            );
            stmt.setString(1, name);
            stmt.setInt(2, Integer.parseInt(id));
            stmt.setString(3, day);
            stmt.setString(4, time);
            stmt.setString(5, "Radwan Batyha");
            stmt.execute();
            conn.close();
            }
             catch(Exception ex)
            {
            Alert msg=new Alert(AlertType.ERROR,"Error "+ex);
            msg.show();
            
            }
        drNameLabel.setText("Dr. Name: Radwan Batyha");
        studentNameLabel.setText("Student Name: " + name);
        studentIdLabel.setText("Student ID: " + id);
        selectedDayLabel.setText("Appointment Day: " + day);
        selectedTimeLabel.setText("Time: " + time);
        
         primaryStage.setScene(scene5);
        }      
        });
        
        btnFinish.setOnAction(e->{
            loadAppointment(currentStudent);
            studentName.clear();
            studentId.clear();
            dayCombo.getSelectionModel().clearSelection();
            timeField.clear();
            primaryStage.setScene(scene3);
        });
        
        //Baraa Submition and finishing
        btnSubmit2.setOnAction(e->{
        String name = studentName2.getText();
        String id = studentId2.getText();
        String day = dayCombo2.getValue();
        String time = timeField2.getText(); 
        if(name.isEmpty()||id.isEmpty()|| day==null|| time.isEmpty()){
         Alert alert = new Alert(Alert.AlertType.WARNING);
        alert.setTitle("Missing Information");
        alert.setHeaderText(null);
        alert.setContentText("Please fill in all the fields before submitting.");
        alert.showAndWait();
        } else{
               try{
                Connection conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/unistudents","root","");
                PreparedStatement stmt = conn.prepareStatement(
                "INSERT INTO appointment (studentname, id, day, time,drname) VALUES (?, ?, ?, ?,?)"
            );
            stmt.setString(1, name);
            stmt.setInt(2, Integer.parseInt(id));
            stmt.setString(3, day);
            stmt.setString(4, time);
            stmt.setString(5,"Baraa Qadomi");
            stmt.execute();
            conn.close();
            }
             catch(Exception ex)
            {
            Alert msg=new Alert(AlertType.ERROR,"Error "+ex);
            msg.show();
            
            }
 
        drNameLabel2.setText("Dr. Name: Baraa Qadomi");
        studentNameLabel2.setText("Student Name: " + name);
        studentIdLabel2.setText("Student ID: " + id);
        selectedDayLabel2.setText("Appointment Day: " + day);
        selectedTimeLabel2.setText("Time: " + time);
         primaryStage.setScene(scene7);
        } 
        });
        
        btnHomePage.setOnAction(e-> primaryStage.setScene(scene3));
        btnHomePage2.setOnAction(e->primaryStage.setScene(scene3));
        
        btnFinish2.setOnAction(e->{
            loadAppointment(currentStudent);
            studentName2.clear();
            studentId2.clear();
            dayCombo2.getSelectionModel().clearSelection();
            timeField2.clear();
            primaryStage.setScene(scene3);
        });
 
        
        
        btnBacktoBaraa.setOnAction(e->primaryStage.setScene(scene3));
        btnBacktoRadwan.setOnAction(e->primaryStage.setScene(scene3));
        
        btnSettings.setOnAction(e-> primaryStage.setScene(scene8));
        //settings control
        btnHome.setOnAction(e-> primaryStage.setScene(scene3) );
        
        btnSaveChanges.setOnAction(e -> {
        if(genderGroup.getSelectedToggle()==null || combo.getSelectionModel().getSelectedItem()==null){
           Alert alert=new Alert(Alert.AlertType.ERROR, "Fill all the items!");
           alert.show();
           alert.setTitle("Empty");
           return;
                } else{
            String selectedLanguage = combo.getSelectionModel().getSelectedItem();
            String selectedGender = male.isSelected() ? "Male" : (female.isSelected() ? "Female" : "Not selected");

            lblSummary.setText("City: " + selectedLanguage + "\nGender: " + selectedGender);
        }
        });
        
        btnChange.setOnAction(e->changePassword());
        btnBack.setOnAction(e->{
                txtName.clear();
                txtID.clear();
                newUser.clear();
               pswReg.clear();
               primaryStage.setScene(scene1);
        
        });
   
       primaryStage.setTitle("Appointment App");
        primaryStage.setScene(scene1);
        primaryStage.show(); 
        primaryStage.setResizable(false);
        primaryStage.setMaximized(false);
    }
    
    //Methods
    public void addStudent(){
    String stmtText="insert into students values(?,?,?,?)";
    if(txtName.getText().isEmpty() || txtID.getText().isEmpty() || newUser.getText().isEmpty() ||pswReg.getText().isEmpty()){
        Alert alert=new Alert(Alert.AlertType.ERROR, "Fill all the items!");
        alert.show();
        alert.setTitle("Empty");
        txtName.clear();
        txtID.clear();
        newUser.clear();
        pswReg.clear();
    }else{
        try{
        Connection conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/unistudents","root","");
        PreparedStatement stmt=conn.prepareStatement(stmtText);
        stmt.setString(1, txtName.getText());
        stmt.setInt(2, Integer.parseInt(txtID.getText()));
        stmt.setString(3, newUser.getText());
        stmt.setString(4, pswReg.getText());
        stmt.execute();
        Alert alert=new Alert(Alert.AlertType.INFORMATION,"A record has been add");
        alert.show();
        txtName.clear();
        txtID.clear();
        newUser.clear();
        pswReg.clear();
        }
        catch(Exception ex){
        Alert alert=new Alert(Alert.AlertType.ERROR,ex.toString());
        alert.show();
        
        }
    }
    }
    
    public void changePassword(){ 
           if(name1.getText().isEmpty()||id2.getText().isEmpty()
              ||userName1.getText().isEmpty()||Pass1.getText().isEmpty())
            {
            Alert msg=new Alert(AlertType.ERROR,"plz fill inth text fields");
            msg.show();
            
            }
        else
        {
         try{
            //1-Conection
           Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/unistudents","root","");
          
            //2-Preppared Statement
          PreparedStatement st=con.prepareStatement(UPDATE_USER);
            //3- parameters
          st.setString(1, name1.getText());
          st.setString(2, userName1.getText());
          st.setString(3, Pass1.getText());
          st.setInt(4, Integer.parseInt(id2.getText()));

            st.execute();
             Alert msg=new Alert(AlertType.INFORMATION,"one user updated");
            msg.show();
            }
            catch(Exception e)
            {
            Alert msg=new Alert(AlertType.ERROR,"Error "+e);
            msg.show();
    }
        }
    }
    
    public void signOut(){
        
         if(txtUser.getText().isEmpty())
            {
            Alert msg=new Alert(AlertType.ERROR,"plz fill in the text fields");
            msg.show();
            
            }
        else
        {
         try{
           Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/unistudents","root","");
          PreparedStatement st=con.prepareStatement(DELETE_USER);
            st.setString(1, txtUser.getText());
            st.execute();
             Alert msg=new Alert(AlertType.INFORMATION,"one user deleted");
             msg.setTitle("Success");
            msg.show();
            }
            catch(Exception ex)
            {
            Alert msg=new Alert(AlertType.ERROR,"Error "+ex);
            msg.show();
            
            }
        }
        }
    public void loadAppointment(int studentId){
    appointmentsList.getItems().clear();
                      try{
                      Connection conn2=DriverManager.getConnection("jdbc:mysql://localhost:3306/unistudents","root","");
                       PreparedStatement stmt2 = conn2.prepareStatement(
                "SELECT drname, day, time FROM appointment WHERE id = ?");
                  stmt2.setInt(1, currentStudent);
                  ResultSet result2 = stmt2.executeQuery();
                       
                  while(result2.next()){
                   String item = "Dr. " + result2.getString("drname") +
                   " | Day: " + result2.getString("day") +
                   " | Time: " + result2.getString("time");
                appointmentsList.getItems().add(item);
                  }
                  conn2.close();
                  }
                  catch(Exception ex ){
                      ex.printStackTrace();
                  }
    }
    
    //Buttons method 
    public void hoverEffect(Button button){
        String originalStyle =button.getStyle();// save the original button 
        //hover 
        button.setOnMouseEntered(e->{
            button.setStyle(originalStyle+ "-fx-background-color: #A9A9A9;"
            + "-fx-text-fill:black;"
            );
        });
        //mouse exit 
        button.setOnMouseExited(e-> button.setStyle(originalStyle));  
    }
      
    public static void main(String[] args) {
        launch(args);
    }
    
}
